from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "user"

    id       = db.Column(db.Integer, primary_key=True)
    email    = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    verified = db.Column(db.Boolean, default=False)
    otp      = db.Column(db.String(6))

    # Pro plan columns
    is_pro      = db.Column(db.Boolean, default=False)
    pro_since   = db.Column(db.DateTime, nullable=True)
    pro_expires = db.Column(db.DateTime, nullable=True)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def is_pro_active(self):
        """Returns True if user has an active Pro subscription."""
        if not self.is_pro:
            return False
        if self.pro_expires and self.pro_expires < datetime.utcnow():
            return False
        return True